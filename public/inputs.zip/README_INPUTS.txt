Dhaga & Co. Return & Review Intelligence Dataset
Contains 48k orders/wk return records, vendor scorecards, and customer feedback.
Archive Size: ~47.4 KB
Prepared for Neha (Category Head) & Vivek (Listing Lead).
